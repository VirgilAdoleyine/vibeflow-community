import { getNangoClient } from "./client";
import { SUPPORTED_INTEGRATIONS } from "@/types/integration";

type Credentials = {
  access_token?: string;
  token?: string;
  api_key?: string;
};

/**
 * Extracts the usable token string from a Nango credentials object.
 * Nango normalises different auth types but the field name varies by provider.
 */
function extractToken(credentials: Credentials | undefined): string | null {
  return credentials?.access_token ?? credentials?.token ?? credentials?.api_key ?? null;
}

/**
 * Fetches all available integration tokens for a user.
 * Returns a map of { provider: accessToken }.
 * Silently skips any provider that is not connected or whose token has expired.
 */
export async function fetchUserTokens(
  userId: string
): Promise<Record<string, string>> {
  const nango = getNangoClient();
  const tokens: Record<string, string> = {};

  await Promise.allSettled(
    SUPPORTED_INTEGRATIONS.map(async ({ provider }) => {
      try {
        const connection = await nango.getConnection(provider, userId);
        const token = extractToken(connection?.credentials as Credentials);
        if (token) {
          tokens[provider] = token;
        }
      } catch {
        // Not connected or revoked — skip silently
      }
    })
  );

  return tokens;
}

/**
 * Fetches a token for a single provider.
 * Throws if not connected or if the token cannot be found.
 */
export async function fetchToken(
  provider: string,
  userId: string
): Promise<string> {
  const nango = getNangoClient();
  const connection = await nango.getConnection(provider, userId);
  const token = extractToken(connection?.credentials as Credentials);

  if (!token) {
    throw new Error(`No token found for provider: ${provider}`);
  }

  return token;
}

/**
 * Detects which integrations a prompt is likely to need so we only fetch the
 * tokens that are actually required for the run.
 */
export function detectRequiredProviders(prompt: string): string[] {
  const lower = prompt.toLowerCase();

  const keywords: Record<string, string[]> = {
    shopify: ["shopify", "order", "product", "customer", "store"],
    slack: ["slack", "message", "channel", "notify", "post"],
    hubspot: ["hubspot", "crm", "contact", "deal", "pipeline"],
    notion: ["notion", "page", "database", "doc"],
    "google-mail": ["gmail", "email", "mail", "inbox"],
    airtable: ["airtable", "base", "table", "record"],
  };

  return Object.entries(keywords)
    .filter(([, terms]) => terms.some((term) => lower.includes(term)))
    .map(([provider]) => provider);
}
