import { Nango } from "@nangohq/node";

let _client: Nango | null = null;

/**
 * Returns a singleton Nango Node SDK client.
 * Throws clearly if NANGO_SECRET_KEY is not configured.
 */
export function getNangoClient(): Nango {
  if (!_client) {
    const secretKey = process.env.NANGO_SECRET_KEY;
    if (!secretKey) {
      throw new Error(
        "NANGO_SECRET_KEY is not set. Add it to your .env.local file."
      );
    }
    _client = new Nango({ secretKey });
  }
  return _client;
}

/**
 * Nango Node SDK v2+ returns { connections: NangoConnection[] }.
 * (The old SDK incorrectly used { configs: ... } — that shape was wrong
 * and caused listConnections to silently always return an empty array.)
 */
interface NangoListConnectionsResponse {
  connections: Array<{
    connection_id: string;
    provider_config_key: string;
    created_at?: string;
    metadata?: Record<string, unknown>;
  }>;
}

/**
 * Returns all Nango connections that belong to the given userId
 * (matched against the connection_id field or the end_user_id tag).
 */
export async function listConnectionsForUser(userId: string) {
  try {
    const nango = getNangoClient();
    const response = (await nango.listConnections()) as NangoListConnectionsResponse;
    const connections = response?.connections ?? [];

    return connections.filter((c) => c.connection_id === userId);
  } catch (err) {
    console.error("[nango] Failed to list connections:", err);
    return [];
  }
}

/**
 * Returns the set of provider keys that are currently connected for a user
 * e.g. ["slack", "shopify"].
 */
export async function getConnectedProviders(userId: string): Promise<string[]> {
  const connections = await listConnectionsForUser(userId);
  return connections.map((c) => c.provider_config_key);
}

/**
 * Checks whether a specific connection is currently valid by attempting to
 * retrieve it. Returns false (not just throws) on 4xx errors so callers can
 * present a "Reconnect" prompt rather than a generic error state.
 */
export async function isConnectionValid(
  provider: string,
  userId: string
): Promise<boolean> {
  try {
    const nango = getNangoClient();
    await nango.getConnection(provider, userId);
    return true;
  } catch (err: unknown) {
    const status = (err as { status?: number })?.status;
    if (status !== undefined && status >= 400 && status < 500) {
      return false; // Invalid / revoked connection — caller should show reconnect UI
    }
    throw err; // Unexpected error — re-throw so the caller sees it
  }
}

/**
 * Deletes (disconnects) a Nango connection for the given provider + user.
 */
export async function deleteConnection(
  provider: string,
  userId: string
): Promise<void> {
  const nango = getNangoClient();
  await nango.deleteConnection(provider, userId);
}
