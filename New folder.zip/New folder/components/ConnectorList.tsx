"use client";

import { useState, useEffect, useCallback } from "react";
import Nango from "@nangohq/frontend";
import { Plug, PlugZap, RefreshCw, ExternalLink, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Integration } from "@/types/integration";

interface ConnectorListProps {
  className?: string;
}

export function ConnectorList({ className }: ConnectorListProps) {
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionState, setActionState] = useState<
    Record<string, "connecting" | "reconnecting" | "disconnecting" | "checking" | null>
  >({});
  const [invalidProviders, setInvalidProviders] = useState<Set<string>>(new Set());



  // ── Data fetching ───────────────────────────────────────────────────────────

  const fetchIntegrations = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/integrations");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setIntegrations(data.integrations ?? []);
    } catch (err) {
      console.error("[ConnectorList] Failed to fetch integrations:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchIntegrations();
  }, [fetchIntegrations]);

  useEffect(() => {
    const connected = integrations.filter((i) => i.status === "connected");
    if (connected.length === 0) return;

    const checkValidity = async () => {
      const invalid = new Set<string>();
      await Promise.allSettled(
        connected.map(async (integration) => {
          try {
            const res = await fetch(`/api/integrations/${integration.provider}`);
            const data = await res.json();
            if (!data.valid) {
              invalid.add(integration.provider);
            }
          } catch {
            // If the check itself fails, don't mark as invalid — avoid false positives
          }
        })
      );
      setInvalidProviders(invalid);
    };

    checkValidity();
  }, [integrations]);

  // ── Helpers ──────────────────────────────────────────────────────────────

  const setAction = (provider: string, state: typeof actionState[string]) =>
    setActionState((prev) => ({ ...prev, [provider]: state }));

  const openNangoFlow = useCallback(
    async (provider: string, mode: "connect" | "reconnect") => {
      setAction(provider, mode === "connect" ? "connecting" : "reconnecting");

      try {
        const endpoint =
          mode === "connect" ? "/api/nango/session" : "/api/nango/reconnect";
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ provider }),
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          throw new Error(err?.error ?? `HTTP ${res.status}`);
        }

        const { sessionToken } = await res.json();

        // Init Nango with the session token, then open the Connect UI.
        const nango = new Nango({ connectSessionToken: sessionToken });
        nango.openConnectUI({
          onEvent: (event) => {
            if (event.type === "close") {
              setAction(provider, null);
            } else if (event.type === "connect") {
              setAction(provider, null);
              setInvalidProviders((prev) => {
                const next = new Set(prev);
                next.delete(provider);
                return next;
              });
              fetchIntegrations();
            }
          },
        });
      } catch (err) {
        console.error(`[ConnectorList] Failed to get session token for ${provider}:`, err);
        setAction(provider, null);
      }
    },
    [fetchIntegrations]
  );

  const handleConnect = useCallback(
    (integration: Integration) => openNangoFlow(integration.provider, "connect"),
    [openNangoFlow]
  );

  const handleReconnect = useCallback(
    (integration: Integration) => openNangoFlow(integration.provider, "reconnect"),
    [openNangoFlow]
  );

  const handleDisconnect = useCallback(
    async (integration: Integration) => {
      setAction(integration.provider, "disconnecting");
      try {
        const res = await fetch(`/api/integrations/${integration.provider}`, {
          method: "DELETE",
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        setInvalidProviders((prev) => {
          const next = new Set(prev);
          next.delete(integration.provider);
          return next;
        });
        await fetchIntegrations();
      } catch (err) {
        console.error(
          `[ConnectorList] Failed to disconnect ${integration.provider}:`,
          err
        );
      } finally {
        setAction(integration.provider, null);
      }
    },
    [fetchIntegrations]
  );

  // ── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className={cn("space-y-2", className)}>
        {Array.from({ length: 4 }).map((_, i) => (
          <div
            key={i}
            className="h-14 rounded-xl bg-zinc-100 dark:bg-zinc-800 animate-pulse"
          />
        ))}
      </div>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-medium text-zinc-700 dark:text-zinc-300">
          Connected apps
        </h3>
        <button
          onClick={fetchIntegrations}
          className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
          title="Refresh"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {integrations.map((integration) => {
        const isConnected = integration.status === "connected";
        const isInvalid = isConnected && invalidProviders.has(integration.provider);
        const currentAction = actionState[integration.provider] ?? null;
        const isBusy = currentAction !== null;

        return (
          <div
            key={integration.id}
            className={cn(
              "flex items-center gap-3 p-3 rounded-xl border transition-all",
              isInvalid
                ? "border-amber-300 bg-amber-50 dark:border-amber-700 dark:bg-amber-950/30"
                : isConnected
                ? "border-emerald-200 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/30"
                : "border-zinc-200 bg-white dark:border-zinc-700 dark:bg-zinc-900 hover:border-zinc-300 dark:hover:border-zinc-600"
            )}
          >
            {/* Icon */}
            <span
              className="w-8 h-8 rounded-lg flex items-center justify-center text-lg flex-shrink-0"
              style={{ backgroundColor: `${integration.color}18` }}
            >
              {integration.icon}
            </span>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-zinc-800 dark:text-zinc-100 leading-tight">
                {integration.display_name}
              </p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 truncate">
                {isInvalid ? (
                  <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 inline-block" />
                    Reconnection required
                  </span>
                ) : (
                  integration.description
                )}
              </p>
            </div>

            {/* Action */}
            {isConnected ? (
              <div className="flex items-center gap-2 flex-shrink-0">
                {isInvalid ? (
                  <button
                    onClick={() => handleReconnect(integration)}
                    disabled={isBusy}
                    className={cn(
                      "flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-all",
                      "bg-amber-500 text-white hover:bg-amber-600 active:scale-95",
                      "disabled:opacity-50 disabled:cursor-not-allowed"
                    )}
                  >
                    {currentAction === "reconnecting" ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        Reconnecting…
                      </>
                    ) : (
                      <>
                        <RefreshCw className="w-3 h-3" />
                        Reconnect
                      </>
                    )}
                  </button>
                ) : (
                  <>
                    <span className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      <PlugZap className="w-3 h-3" />
                      Live
                    </span>
                    <button
                      onClick={() => handleDisconnect(integration)}
                      disabled={isBusy}
                      className="text-xs text-zinc-400 hover:text-red-500 transition-colors ml-1 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {currentAction === "disconnecting" ? (
                        <RefreshCw className="w-3 h-3 animate-spin" />
                      ) : (
                        "Disconnect"
                      )}
                    </button>
                  </>
                )}
              </div>
            ) : (
              <button
                onClick={() => handleConnect(integration)}
                disabled={isBusy}
                className={cn(
                  "flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-all flex-shrink-0",
                  "bg-zinc-900 dark:bg-white text-white dark:text-zinc-900",
                  "hover:bg-zinc-700 dark:hover:bg-zinc-100 active:scale-95",
                  "disabled:opacity-50 disabled:cursor-not-allowed"
                )}
              >
                {currentAction === "connecting" ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Connecting…
                  </>
                ) : (
                  <>
                    <Plug className="w-3 h-3" />
                    Connect
                  </>
                )}
              </button>
            )}
          </div>
        );
      })}

      <p className="text-xs text-zinc-400 dark:text-zinc-500 pt-1">
        OAuth is handled by{" "}
        <a
          href="https://nango.dev"
          target="_blank"
          rel="noopener noreferrer"
          className="underline underline-offset-2 hover:text-zinc-600 dark:hover:text-zinc-300 inline-flex items-center gap-0.5"
        >
          Nango <ExternalLink className="w-2.5 h-2.5" />
        </a>{" "}
        — your credentials are never stored here.
      </p>
    </div>
  );
}