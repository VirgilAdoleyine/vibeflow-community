import { NextRequest, NextResponse } from "next/server";
import { getNangoClient } from "@/lib/integrations/client";
import { getCurrentUserId } from "@/lib/auth/user";
import { SUPPORTED_INTEGRATIONS } from "@/types/integration";

export const runtime = "nodejs";

/**
 * POST /api/nango/reconnect
 *
 * Creates a Nango re-connect session token for an existing connection whose
 * credentials have expired or whose scopes have changed. Using this endpoint
 * (rather than deleting and re-creating the connection) preserves all
 * associated syncs, actions, and connection metadata.
 *
 * Body:
 *   { provider: string }   — integration.provider value
 *
 * Returns:
 *   { sessionToken: string }
 */
export async function POST(req: NextRequest) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let provider: string | undefined;
  try {
    const body = await req.json();
    provider = body?.provider;
  } catch {
    // fall through to validation below
  }

  if (!provider) {
    return NextResponse.json(
      { error: "provider is required in the request body" },
      { status: 400 }
    );
  }

  const known = SUPPORTED_INTEGRATIONS.map((i) => i.provider);
  if (!known.includes(provider)) {
    return NextResponse.json(
      { error: `Unknown provider: ${provider}` },
      { status: 400 }
    );
  }

  try {
    const nango = getNangoClient();

    // createReconnectSession updates credentials on the existing connection
    // without deleting its data, syncs, or configuration.
    const { data } = await nango.createReconnectSession({
      connection_id: userId,
      integration_id: provider,
    });

    return NextResponse.json({ sessionToken: data.token });
  } catch (err) {
    console.error("[nango/reconnect] Failed to create reconnect session:", err);
    return NextResponse.json(
      { error: "Failed to create reconnect session token" },
      { status: 500 }
    );
  }
}