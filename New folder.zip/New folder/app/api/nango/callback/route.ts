import { NextRequest } from "next/server";

export const runtime = "nodejs";

/**
 * GET /api/nango/callback
 *
 * Legacy OAuth redirect handler. Kept for providers that bypass the Nango
 * Connect UI and redirect the user's browser directly to your app's callback
 * URL (e.g. some enterprise OAuth flows).
 *
 * For the standard Connect UI flow this route is NOT called — the Nango
 * Connect UI handles the OAuth round-trip entirely within its own iframe/popup
 * and notifies your frontend through the onEvent callback instead.
 *
 * If you set a custom OAuth callback URL in Nango (Environment Settings →
 * Callback URL), point it at this route:
 *   https://yourdomain.com/api/nango/callback  →  308 redirect to api.nango.dev/oauth/callback
 *
 * Note: this route does NOT expose the connectionId to the window opener.
 * The connectionId is delivered server-side via the POST webhook to
 * /api/nango/webhook instead.
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const error = searchParams.get("error");

  // Pass all original query params through to Nango's OAuth callback endpoint.
  // This satisfies any provider that requires the callback to relay the code.
  const nangoCallbackUrl = new URL("https://api.nango.dev/oauth/callback");
  searchParams.forEach((value, key) => nangoCallbackUrl.searchParams.set(key, value));

  if (error) {
    // Show a simple error page — the Connect UI will also surface this via onEvent.
    const html = `<!DOCTYPE html>
<html>
<head><title>Authorization failed</title></head>
<body style="font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
  <div style="text-align:center">
    <p style="color:#ef4444;font-size:14px">Authorization failed: ${encodeURIComponent(error)}</p>
    <p style="color:#71717a;font-size:12px">You can close this window.</p>
  </div>
</body>
</html>`;
    return new Response(html, { headers: { "Content-Type": "text/html" } });
  }

  // 308 Permanent Redirect — passes the method and body through (safe for GET).
  return new Response(null, {
    status: 308,
    headers: { Location: nangoCallbackUrl.toString() },
  });
}
