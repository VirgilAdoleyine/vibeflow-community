import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

/**
 * POST /api/nango/webhook
 *
 * Receives webhook notifications from Nango. Register this URL in the Nango
 * dashboard under Environment Settings → Webhook URL and enable the
 * "Send New Connection Creation Webhooks" option.
 *
 * This is the production-safe way to learn about new connections.
 * The connectionId must be persisted here (server-side) and never exposed
 * to the frontend.
 *
 * Nango sends POST requests with this shape on successful auth:
 * {
 *   type: "auth",
 *   operation: "creation" | "override",   // "override" = re-authorization
 *   success: true,
 *   connectionId: string,
 *   providerConfigKey: string,
 *   endUser: { id: string },              // matches userId from session token
 * }
 *
 * For failed auth:
 * {
 *   type: "auth",
 *   success: false,
 *   error: string,
 *   ...
 * }
 */
export async function POST(req: NextRequest) {
  // ── Signature verification ────────────────────────────────────────────────
  // Nango signs every webhook with an HMAC-SHA256 signature using the
  // NANGO_WEBHOOK_SECRET you set in Environment Settings. Verifying this
  // prevents spoofed webhook calls.
  //
  // Uncomment and configure once you have set NANGO_WEBHOOK_SECRET:
  //
  // import { createHmac, timingSafeEqual } from "crypto";
  // const secret = process.env.NANGO_WEBHOOK_SECRET;
  // if (secret) {
  //   const signature = req.headers.get("x-nango-signature") ?? "";
  //   const rawBody = await req.text();
  //   const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  //   const match = timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  //   if (!match) {
  //     console.warn("[nango/webhook] Invalid signature — rejecting request");
  //     return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  //   }
  //   // Parse body from text now that we've verified it
  //   const payload = JSON.parse(rawBody);
  //   await handleWebhook(payload);
  //   return NextResponse.json({ ok: true });
  // }
  // ── End signature verification ────────────────────────────────────────────

  let payload: Record<string, unknown>;
  try {
    payload = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  await handleWebhook(payload);
  // Nango expects a 2xx response to confirm delivery. Any non-2xx will trigger
  // a retry with exponential back-off.
  return NextResponse.json({ ok: true });
}

async function handleWebhook(payload: Record<string, unknown>) {
  const { type, operation, success, connectionId, providerConfigKey, endUser } = payload as {
    type: string;
    operation?: string;
    success: boolean;
    connectionId?: string;
    providerConfigKey?: string;
    endUser?: { id?: string };
    error?: string;
  };

  if (type !== "auth") {
    // Nango also sends sync, action, and error webhooks — ignore for now.
    return;
  }

  if (!success) {
    console.warn(
      `[nango/webhook] Auth failed — provider=${providerConfigKey} user=${endUser?.id} error=${payload.error}`
    );
    return;
  }

  const userId = endUser?.id;
  const isNew = operation === "creation";
  const isReconnect = operation === "override";

  console.log(
    `[nango/webhook] Auth success — ${isNew ? "new" : isReconnect ? "reconnected" : operation} ` +
    `provider=${providerConfigKey} connectionId=${connectionId} userId=${userId}`
  );

  // ── Persist the connectionId ───────────────────────────────────────────────
  // This is where you store the mapping of connectionId ↔ your user/entity.
  // Example using the executions DB client:
  //
  // import sql from "@/lib/db/client";
  // await sql`
  //   INSERT INTO nango_connections (user_id, provider, connection_id, created_at)
  //   VALUES (${userId}, ${providerConfigKey}, ${connectionId}, NOW())
  //   ON CONFLICT (user_id, provider) DO UPDATE
  //     SET connection_id = EXCLUDED.connection_id,
  //         updated_at    = NOW()
  // `;
  //
  // For now we log — add the DB write once you have created the table.
  // ─────────────────────────────────────────────────────────────────────────
}
