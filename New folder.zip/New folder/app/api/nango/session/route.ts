import { NextRequest, NextResponse } from "next/server";
import { getNangoClient } from "@/lib/integrations/client";
import { getCurrentUserId } from "@/lib/auth/user";
import { SUPPORTED_INTEGRATIONS } from "@/types/integration";

export const runtime = "nodejs";

/**
 * POST /api/nango/session
 *
 * Creates a short-lived Nango Connect session token that the frontend SDK uses
 * to open the Connect UI. This keeps the Nango secret key server-side only.
 *
 * Body (optional):
 *   { provider?: string }   — integration.provider value (e.g. "google-mail").
 *                             If supplied, sends the user directly to that
 *                             provider's auth flow; otherwise shows the full list.
 *
 * Returns:
 *   { sessionToken: string }
 */
export async function POST(req: NextRequest) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let provider: string | undefined;
  try {
    const body = await req.json();
    provider = body?.provider ?? undefined;
  } catch {
    // No body — allowed
  }

  // Validate that the requested provider is one we support
  if (provider) {
    const known = SUPPORTED_INTEGRATIONS.map((i) => i.provider);
    if (!known.includes(provider)) {
      return NextResponse.json(
        { error: `Unknown provider: ${provider}` },
        { status: 400 }
      );
    }
  }

  try {
    const nango = getNangoClient();

    // SDK v0.69+: end_user is a top-level object; organization tags go inside
    // end_user.tags. The old end_user+organization shape and the flat tags shape
    // were both deprecated and are rejected by Nango Cloud.
    const { data } = await nango.createConnectSession({
      end_user: {
        id: userId,
        tags: {
          organizationId: "vibeflow",
        },
      },
      // allowed_integrations must match the provider_config_key values
      // configured in your Nango dashboard — these are integration.provider
      // values (e.g. "google-mail" for Gmail, "slack" for Slack, etc.).
      allowed_integrations: provider
        ? [provider]
        : SUPPORTED_INTEGRATIONS.map((i) => i.provider),
    });

    return NextResponse.json({ sessionToken: data.token });
  } catch (err) {
    console.error("[nango/session] Failed to create connect session:", err);
    return NextResponse.json(
      { error: "Failed to create session token" },
      { status: 500 }
    );
  }
}