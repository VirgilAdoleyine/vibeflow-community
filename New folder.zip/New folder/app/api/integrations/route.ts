import { NextRequest, NextResponse } from "next/server";
import { getConnectedProviders, deleteConnection } from "@/lib/integrations/client";
import { getCurrentUserId } from "@/lib/auth/user";
import { SUPPORTED_INTEGRATIONS } from "@/types/integration";

export const runtime = "nodejs";

/**
 * GET /api/integrations
 *
 * Returns the list of supported integrations with their connection status for
 * the current user. Uses the corrected Nango response shape
 * ({ connections: [...] } not { configs: [...] }).
 */
export async function GET(_req: NextRequest) {
  const userId = await getCurrentUserId();

  if (!userId) {
    // No session — return all as disconnected so the UI still renders.
    return NextResponse.json({
      integrations: SUPPORTED_INTEGRATIONS.map((i) => ({
        ...i,
        status: "disconnected",
      })),
    });
  }

  try {
    const connectedProviders = await getConnectedProviders(userId);

    const integrations = SUPPORTED_INTEGRATIONS.map((integration) => ({
      ...integration,
      status: connectedProviders.includes(integration.provider)
        ? "connected"
        : "disconnected",
    }));

    return NextResponse.json({ integrations });
  } catch (err) {
    console.error("[api/integrations] Failed to fetch connections:", err);
    // Degrade gracefully — show all as disconnected rather than a 500.
    return NextResponse.json({
      integrations: SUPPORTED_INTEGRATIONS.map((i) => ({
        ...i,
        status: "disconnected",
      })),
    });
  }
}

/**
 * DELETE /api/integrations/:provider
 *
 * Disconnects the given provider for the current user.
 * Note: this also deletes all syncs and data associated with the connection
 * in Nango — there is no undo. Use reconnect (PATCH) if you only need to
 * refresh credentials.
 */
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ provider: string }> }
) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { provider } = await params;
  if (!provider) {
    return NextResponse.json({ error: "provider is required" }, { status: 400 });
  }

  try {
    await deleteConnection(provider, userId);
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(`[api/integrations] Failed to delete connection for ${provider}:`, err);
    return NextResponse.json(
      { error: "Failed to disconnect integration" },
      { status: 500 }
    );
  }
}
